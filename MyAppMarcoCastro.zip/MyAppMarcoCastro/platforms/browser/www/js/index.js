// URL base de tu servidor en PythonAnywhere
const API_URL = "https://marcocastro60318.pythonanywhere.com";

document.addEventListener('deviceready', onDeviceReady, false);

function onDeviceReady() {
    // Notificar estado de Cordova listo
    const parentElement = document.getElementById('deviceready');
    if (parentElement) {
        parentElement.querySelector('.listening').setAttribute('style', 'display:none;');
        parentElement.querySelector('.received').setAttribute('style', 'display:block;');
    }

    // Inicializar listeners
    initApp();
}

function initApp() {
    const loginForm = document.getElementById('loginForm');
    const togglePassBtn = document.getElementById('togglePass');
    const passwordInput = document.getElementById('password');
    const logoutBtn = document.getElementById('logoutBtn');

    // 1. Mostrar / Ocultar contraseña
    if (togglePassBtn && passwordInput) {
        togglePassBtn.addEventListener('click', () => {
            const isPassword = passwordInput.type === 'password';
            passwordInput.type = isPassword ? 'text' : 'password';
        });
    }

    // 2. Manejo del envío del formulario Login
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }

    // 3. Botón para cerrar sesión
    if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
            document.getElementById('successCard').hidden = true;
            document.getElementById('loginCard').hidden = false;
            loginForm.reset();
        });
    }
}

async function handleLogin(e) {
    e.preventDefault();

    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    const emailError = document.getElementById('emailError');
    const passError = document.getElementById('passError');
    const submitBtn = document.getElementById('submitBtn');

    // Limpiar errores previos
    emailError.textContent = '';
    passError.textContent = '';

    const email = emailInput.value.trim();
    const password = passwordInput.value.trim();

    // Validaciones básicas de cliente
    if (!email) {
        emailError.textContent = 'Ingresa tu correo electrónico.';
        return;
    }
    if (!password) {
        passError.textContent = 'Ingresa tu contraseña.';
        return;
    }

    // Activar estado de carga (loading)
    submitBtn.classList.add('loading');
    submitBtn.disabled = true;

    try {
        // Petición HTTP a la API de PythonAnywhere
        const response = await fetch(`${API_URL}/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                email: email,
                password: password
            })
        });

        const data = await response.json();

        if (response.ok) {
            // Éxito (HTTP 200)
            document.getElementById('welcomeMsg').textContent = data.Exito || "¡Bienvenido de nuevo!";
            document.getElementById('loginCard').hidden = true;
            document.getElementById('successCard').hidden = false;
        } else {
            // Error enviado por el servidor (HTTP 401, 400, etc.)
            passError.textContent = data.Error || 'Credenciales inválidas.';
        }

    } catch (error) {
        console.error('Error de red o conexión:', error);
        passError.textContent = 'No se pudo conectar con el servidor. Revisa tu conexión.';
    } finally {
        // Desactivar estado de carga
        submitBtn.classList.remove('loading');
        submitBtn.disabled = false;
    }
}